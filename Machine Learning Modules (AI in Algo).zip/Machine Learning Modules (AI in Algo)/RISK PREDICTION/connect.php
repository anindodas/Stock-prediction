<?php
	$conn = mysqli_connect('localhost','root','user_data','')
	if(!$conn)
	{
		die('Could not connect');
	}
	
	
?>
